<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2.7 detail</title>
</head>

<body>

    <div class="container" style="margin: 10 auto; width: 700px;">
        <table align="center" bgcolor="#FEFEFE">
            <tr bgcolor="#FFEEE6">
                <td colspan="3" align="center"><h1> Nguyễn Tiến Anh</h1></td>
            </tr>
            <tr>
                <td colspan="1"><img src="../img/ta.jpg" alt='' width="250px" height="350px"></td>
                <td>
                    <p>Ngày sinh: 17/02/2002</p>
                    <p>Giới tính : Nam</p>
                    <p>Lớp : D15CNPM2</p>
                    <p>Số điện thoại: 0971366275</p>
                    <p>Email: nguyentienanh@gmail.com</p>
                    <p>Mã sinh viên : 20810310287</p>
                    <p>Sở thích:<p> - Chơi Game  </p><p> - Nghe nhạc   </p><p>- Xem phim  </p></p> </td>
            </tr>
        </table>
    </div>
    <br>
    <!-------------------------------------------------------->
    <div class="container" style="margin: 10 auto; width: 700px;">
        <table align="center" bgcolor="#FEFEFE">
            <tr bgcolor="#FFEEE6">
                <td colspan="3" align="center"><h1> Võ Văn Thắng</h1></td>
            </tr>
            <tr>
                <td colspan="1"><img src="../img/thang.jpg" alt='' width="250px" height="350px"></td>
                <td>
                    <p>Ngày sinh: 19/11/2002</p>
                    <p>Giới tính : Nam</p>
                    <p>Lớp : D15CNPM2</p>
                    <p>Số điện thoại: 09297384832</p>
                    <p>Email: thangpro9669@gmail.com</p>
                    <p>Mã sinh viên : 20810310066</p>
                    <p>Sở thích:<p> - Chơi Game  </p><p> - Nghe nhạc   </p><p>- Xem phim  </p> <p>- Chơi bóng đá  </p></p> </td>
            </tr>
        </table>
        <br>
    </div>
        <!-------------------------------------------------------->
        <div class="container" style="margin: 0 auto; width: 700px;">
        <table align="center" bgcolor="#FEFEFE">
            <tr bgcolor="#FFEEE6">
                <td colspan="3" align="center"><h1> Hoàng Văn Phúc</h1></td>
            </tr>
            <tr>
                <td colspan="1"><img src="../img/phuc.jpg" alt='' width="250px" height="350px"></td>
                <td>
                    <p>Ngày sinh: 15/03/2002</p>
                    <p>Giới tính : Nam</p>
                    <p>Lớp : D15CNPM2</p>
                    <p>Số điện thoại: 0779077606</p>
                    <p>Email: phuc21102@gmail.com</p>
                    <p>Mã sinh viên : 20810310295</p>
                    <p>Sở thích:<p> - Chơi Game  </p><p> - Chơi đàn  </p><p>- Thể thao  </p></p> </td>
            </tr>
        </table>
    </div>
    <style>

    td {
        padding: 2px 10px;
        border: 1px solid #222;
    }
    p{
        color:  #F08002;
        font-style: bold;
        font-size: 20px;
    }
    </style>
</body>

</html>