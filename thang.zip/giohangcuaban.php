<span><?php if(isset($_SESSION['giohang'])) {echo count($_SESSION['giohang']);} else {echo 0;}?></span>
	